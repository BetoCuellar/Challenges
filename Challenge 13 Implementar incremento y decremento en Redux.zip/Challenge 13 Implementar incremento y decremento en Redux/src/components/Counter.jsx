// src/components/Counter.jsx
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement, incrementByAmount } from '../store/slices/counterSlice';

const Counter = () => {
  const count = useSelector((state) => state.counter.value);
  const dispatch = useDispatch();
  const [incrementValue, setIncrementValue] = useState(0);

  const handleIncrementByAmount = () => {
    dispatch(incrementByAmount(Number(incrementValue)));
  };

  return (
    <div>
      <h1>Counter: {count}</h1>
      <button onClick={() => dispatch(increment())}>Increment</button>
      <button onClick={() => dispatch(decrement())}>Decrement</button>
      <input
        type="number"
        value={incrementValue}
        onChange={(e) => setIncrementValue(e.target.value)}
        placeholder="Increment by..."
      />
      <button onClick={handleIncrementByAmount}>Increment by Amount</button>
    </div>
  );
};

export default Counter;
