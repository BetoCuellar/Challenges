import React, { useState, useMemo } from 'react';

const MemoComponent = () => {
    const [counter, setCounter] = useState(0);
    const [show, setShow] = useState(true);

    const heavyCalculation = useMemo(() => {
        let result = 0;
        for (let i = 0; i < 1000000000; i++) result += i;
        return result;
    }, []);

    return (
        <div>
            <h1>Counter: {counter}</h1>
            <p>Heavy Calculation Result: {heavyCalculation}</p>
            <button onClick={() => setCounter(counter + 1)}>Increment</button>
            <button onClick={() => setShow(!show)}>
                {show ? 'Hide' : 'Show'}
            </button>
        </div>
    );
};

export default MemoComponent;
