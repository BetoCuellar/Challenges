import React, { useState, useCallback } from 'react';

const CallbackComponent = () => {
    const [counter, setCounter] = useState(0);

    const increment = useCallback(() => {
        setCounter((prevCounter) => prevCounter + 1);
    }, []);

    return (
        <div>
            <h1>Counter: {counter}</h1>
            <button onClick={increment}>Increment</button>
        </div>
    );
};

export default CallbackComponent;
