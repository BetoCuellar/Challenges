import React, { useState } from 'react';
import TodoForm from './TodoForm';
import TodoList from './TodoList';

const TodoApp = () => {
    const [todos, setTodos] = useState([]);

    const addTodo = (todo) => setTodos([...todos, todo]);
    const handleDelete = (id) => setTodos(todos.filter((todo) => todo.id !== id));

    return (
        <div>
            <h1>Todo List</h1>
            <TodoForm addTodo={addTodo} />
            <TodoList todos={todos} handleDelete={handleDelete} />
        </div>
    );
};

export default TodoApp;
