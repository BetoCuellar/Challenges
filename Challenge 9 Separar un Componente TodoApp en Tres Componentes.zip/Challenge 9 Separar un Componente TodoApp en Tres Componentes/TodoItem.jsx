import React from 'react';

const TodoItem = ({ todo, handleDelete }) => {
    return (
        <li>
            {todo.text}
            <button onClick={() => handleDelete(todo.id)}>Delete</button>
        </li>
    );
};

export default TodoItem;
