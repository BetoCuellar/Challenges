// src/context/UserContext.jsx
import React, { createContext, useState } from 'react';

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [lastVisitedPage, setLastVisitedPage] = useState('/');

  const login = (username) => {
    setUser({ username });
  };

  const logout = () => {
    setUser(null);
  };

  const updateLastVisitedPage = (page) => {
    setLastVisitedPage(page);
  };

  return (
    <UserContext.Provider value={{ user, login, logout, lastVisitedPage, updateLastVisitedPage }}>
      {children}
    </UserContext.Provider>
  );
};
