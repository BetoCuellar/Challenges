// src/components/NavComponent.jsx
import React, { useContext } from 'react';
import { UserContext } from '../context/UserContext';
import { NavLink } from 'react-router-dom';
import Logout from './Logout';

const NavComponent = () => {
  const { user } = useContext(UserContext);

  return (
    <nav className="nav-container">
      <NavLink to="/home" className="nav-link">
        Home
      </NavLink>
      <NavLink to="/dashboard" className="nav-link">
        Dashboard
      </NavLink>
      {user ? (
        <>
          <span>Welcome, {user.username}!</span>
          <Logout />
        </>
      ) : (
        <NavLink to="/login" className="nav-link">
          Login
        </NavLink>
      )}
    </nav>
  );
};

export default NavComponent;
