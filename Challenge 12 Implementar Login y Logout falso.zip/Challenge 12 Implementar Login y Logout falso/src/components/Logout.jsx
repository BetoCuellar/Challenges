// src/components/Logout.jsx
import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../context/UserContext';

const Logout = () => {
  const { logout, updateLastVisitedPage } = useContext(UserContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    updateLastVisitedPage('/');
    logout();
    navigate('/login', { replace: true });
  };

  return <button onClick={handleLogout}>Logout</button>;
};

export default Logout;
