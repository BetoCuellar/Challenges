// src/components/ImageUploader.jsx
import React, { useState } from 'react';
import useFirebaseStorage from '../hooks/useFirebaseStorage';

const ImageUploader = () => {
  const { uploadImage, deleteImage, uploading, error } = useFirebaseStorage();
  const [images, setImages] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    const path = `images/${selectedFile.name}`;
    const downloadURL = await uploadImage(selectedFile, path);

    if (downloadURL) {
      setImages((prevImages) => [...prevImages, { url: downloadURL, path }]);
    }
  };

  const handleDelete = async (path) => {
    await deleteImage(path);
    setImages((prevImages) => prevImages.filter((image) => image.path !== path));
  };

  return (
    <div>
      <h2>Upload Image</h2>
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleUpload} disabled={uploading}>
        {uploading ? 'Uploading...' : 'Upload'}
      </button>
      {error && <p>{error}</p>}
      <h2>Uploaded Images</h2>
      <ul>
        {images.map((image, index) => (
          <li key={index}>
            <img src={image.url} alt={`Uploaded ${index}`} width="100" />
            <button onClick={() => handleDelete(image.path)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ImageUploader;
