// src/hooks/useFirebaseStorage.js
import { useState } from 'react';
import { ref, uploadBytes, getDownloadURL, deleteObject } from '../firebase/config';

const useFirebaseStorage = () => {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);

  const uploadImage = async (file, path) => {
    setUploading(true);
    setError(null);
    const storageRef = ref(path);

    try {
      const snapshot = await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(snapshot.ref);
      setUploading(false);
      return downloadURL;
    } catch (err) {
      setError(err.message);
      setUploading(false);
      return null;
    }
  };

  const deleteImage = async (path) => {
    const storageRef = ref(path);
    try {
      await deleteObject(storageRef);
      console.log('Image deleted successfully');
    } catch (err) {
      setError(err.message);
    }
  };

  return { uploadImage, deleteImage, uploading, error };
};

export default useFirebaseStorage;
