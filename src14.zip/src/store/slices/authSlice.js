// src/store/slices/authSlice.js
import { createSlice } from '@reduxjs/toolkit';

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null,
    status: 'idle', // 'authenticated', 'unauthenticated'
  },
  reducers: {
    loginSuccess: (state, action) => {
      state.user = action.payload;
      state.status = 'authenticated';
    },
    logoutSuccess: (state) => {
      state.user = null;
      state.status = 'unauthenticated';
    },
  },
});

export const { loginSuccess, logoutSuccess } = authSlice.actions;
export default authSlice.reducer;
