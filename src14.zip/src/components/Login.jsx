// src/components/Login.jsx
import React, { useState, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loginWithEmail, loginWithGoogle } from '../store/slices/authThunks';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch();
  const { status } = useSelector((state) => state.auth);

  const isAuthenticated = useMemo(() => status === 'authenticated', [status]);

  const handleLoginWithEmail = () => {
    dispatch(loginWithEmail(email, password));
  };

  const handleLoginWithGoogle = () => {
    dispatch(loginWithGoogle());
  };

  return (
    <div>
      <h2>Login</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        disabled={isAuthenticated}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        disabled={isAuthenticated}
      />
      <button onClick={handleLoginWithEmail} disabled={isAuthenticated}>
        Login with Email
      </button>
      <button onClick={handleLoginWithGoogle} disabled={isAuthenticated}>
        Login with Google
      </button>
    </div>
  );
};

export default Login;
