// src/components/NavComponent.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import Logout from './Logout';

const NavComponent = () => {
  const { user } = useSelector((state) => state.auth);

  return (
    <nav>
      <a href="/home">Home</a>
      <a href="/dashboard">Dashboard</a>
      {user ? (
        <>
          <span>Welcome, {user.email}!</span>
          <Logout />
        </>
      ) : (
        <a href="/login">Login</a>
      )}
    </nav>
  );
};

export default NavComponent;
