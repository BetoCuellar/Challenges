import React from 'react';
import useTodo from './hooks/useTodo';
import TodoForm from './TodoForm';
import TodoList from './TodoList';

const TodoApp = () => {
  const { todos, addTodo, deleteTodo, toggleTodo, countTodos, countPendingTodos } = useTodo();

  return (
    <div>
      <h1>Todo App</h1>
      <p>Total Todos: {countTodos}</p>
      <p>Pending Todos: {countPendingTodos}</p>
      <TodoForm onAddTodo={addTodo} />
      <TodoList todos={todos} onDeleteTodo={deleteTodo} onToggleTodo={toggleTodo} />
    </div>
  );
};

export default TodoApp;
