import { useReducer } from 'react';

const todoReducer = (state, action) => {
  switch (action.type) {
    case 'add':
      return [...state, { id: Date.now(), text: action.payload, completed: false }];
    case 'delete':
      return state.filter((todo) => todo.id !== action.payload);
    case 'toggle':
      return state.map((todo) =>
        todo.id === action.payload ? { ...todo, completed: !todo.completed } : todo
      );
    default:
      return state;
  }
};

const useTodo = () => {
  const [todos, dispatch] = useReducer(todoReducer, []);

  const addTodo = (text) => {
    dispatch({ type: 'add', payload: text });
  };

  const deleteTodo = (id) => {
    dispatch({ type: 'delete', payload: id });
  };

  const toggleTodo = (id) => {
    dispatch({ type: 'toggle', payload: id });
  };

  const countTodos = todos.length;
  const countPendingTodos = todos.filter((todo) => !todo.completed).length;

  return {
    todos,
    addTodo,
    deleteTodo,
    toggleTodo,
    countTodos,
    countPendingTodos,
  };
};

export default useTodo;
