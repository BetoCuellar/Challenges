// src/App.jsx
import React from 'react';
import CrudComponent from './components/CrudComponent';

const App = () => {
  return (
    <div>
      <h1>Firebase Firestore CRUD Challenge</h1>
      <CrudComponent />
    </div>
  );
};

export default App;
