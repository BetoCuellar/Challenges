// src/components/CrudComponent.jsx
import React, { useState } from 'react';
import useFirestore from '../hooks/useFirestore';

const CrudComponent = () => {
  const { data, addItem, updateItem, deleteItem, loading, error } = useFirestore('items');
  const [newItem, setNewItem] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editingText, setEditingText] = useState('');

  const handleAddItem = () => {
    if (newItem.trim()) {
      addItem({ text: newItem });
      setNewItem('');
    }
  };

  const handleEditItem = (id, text) => {
    setEditingId(id);
    setEditingText(text);
  };

  const handleUpdateItem = () => {
    if (editingText.trim()) {
      updateItem(editingId, { text: editingText });
      setEditingId(null);
      setEditingText('');
    }
  };

  return (
    <div>
      <h2>CRUD Component</h2>
      <input
        type="text"
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
        placeholder="Add new item"
      />
      <button onClick={handleAddItem}>Add</button>

      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}

      <ul>
        {data.map((item) => (
          <li key={item.id}>
            {editingId === item.id ? (
              <>
                <input
                  type="text"
                  value={editingText}
                  onChange={(e) => setEditingText(e.target.value)}
                />
                <button onClick={handleUpdateItem}>Update</button>
                <button onClick={() => setEditingId(null)}>Cancel</button>
              </>
            ) : (
              <>
                <span>{item.text}</span>
                <button onClick={() => handleEditItem(item.id, item.text)}>Edit</button>
                <button onClick={() => deleteItem(item.id)}>Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CrudComponent;
