// src/hooks/useFirestore.js
import { useState, useEffect } from 'react';
import { db, collection, addDoc, getDocs, doc, updateDoc, deleteDoc } from '../firebase/config';

const useFirestore = (collectionName) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const querySnapshot = await getDocs(collection(db, collectionName));
      const docsData = querySnapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
      setData(docsData);
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  const addItem = async (item) => {
    try {
      const docRef = await addDoc(collection(db, collectionName), item);
      setData((prevData) => [...prevData, { ...item, id: docRef.id }]);
    } catch (err) {
      setError(err.message);
    }
  };

  const updateItem = async (id, updatedData) => {
    try {
      const itemRef = doc(db, collectionName, id);
      await updateDoc(itemRef, updatedData);
      setData((prevData) =>
        prevData.map((item) => (item.id === id ? { ...item, ...updatedData } : item))
      );
    } catch (err) {
      setError(err.message);
    }
  };

  const deleteItem = async (id) => {
    try {
      const itemRef = doc(db, collectionName, id);
      await deleteDoc(itemRef);
      setData((prevData) => prevData.filter((item) => item.id !== id));
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return { data, addItem, updateItem, deleteItem, loading, error };
};

export default useFirestore;
